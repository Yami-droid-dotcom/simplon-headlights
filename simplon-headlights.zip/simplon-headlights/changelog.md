# Changelog

## 0.1.0

- Création du projet Simplon Headlights
- Ajout de l’interface Google Apps Script
- Ajout des templates de mails
- Ajout de la prévisualisation HTML
- Ajout de l’envoi Gmail
- Ajout de la pièce jointe PDF
- Ajout du bouton “Ajouter le staff Simplon”
