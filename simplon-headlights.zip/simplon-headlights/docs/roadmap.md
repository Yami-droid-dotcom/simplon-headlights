# Roadmap — Simplon Headlights

## MVP

- [x] Interface simple
- [x] Sélection de templates
- [x] Prévisualisation HTML
- [x] Ajout de destinataires
- [x] Ajout du staff Simplon en un clic
- [x] Pièce jointe PDF
- [x] Envoi Gmail

## Prochaines évolutions

- [ ] Sauvegarder les templates dans Google Sheets
- [ ] Ajouter un historique d’envoi
- [ ] Importer les destinataires depuis un CSV
- [ ] Ajouter plusieurs pièces jointes
- [ ] Ajouter un bouton “envoyer un test”
- [ ] Remplacer automatiquement plus de variables : `{{date}}`, `{{lieu}}`, `{{formation}}`
- [ ] Ajouter une gestion des groupes de destinataires
