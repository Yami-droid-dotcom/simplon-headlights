# Présentation — Simplon Headlights

Simplon Headlights fait partie de la suite d’outils internes Simplon Tools.

## Concept

Chaque outil interne porte le nom d’une pièce automobile. Headlights représente les phares : il sert à éclairer, signaler et rendre les informations visibles.

## Objectif

Permettre aux équipes d’envoyer rapidement des mails professionnels à partir de templates réutilisables.

## Cas d’usage

- Convocations
- Informations collectives
- Relances de documents
- Invitations à des ateliers
- Envoi de briefs projet
- Communication partenaires
- Prospection
