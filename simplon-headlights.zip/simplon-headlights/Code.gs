function doGet() {
  return HtmlService
    .createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Simplon Headlights')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function envoyerMails(data) {
  const sujet = data.sujet;
  const htmlTemplate = data.htmlTemplate;
  const destinatairesRaw = data.destinataires;
  const pieceJointe = data.pieceJointe;

  if (!sujet || !htmlTemplate || !destinatairesRaw) {
    throw new Error("Merci de remplir le sujet, le template HTML et les destinataires.");
  }

  const lignes = destinatairesRaw
    .split('\n')
    .map(ligne => ligne.trim())
    .filter(ligne => ligne !== '');

  if (lignes.length === 0) {
    throw new Error("Aucun destinataire valide n'a été renseigné.");
  }

  let attachments = [];

  if (pieceJointe && pieceJointe.contenu) {
    const blob = Utilities.newBlob(
      Utilities.base64Decode(pieceJointe.contenu),
      pieceJointe.type,
      pieceJointe.nom
    );

    attachments.push(blob);
  }

  let envoyes = [];
  let erreurs = [];

  lignes.forEach((ligne, index) => {
    try {
      let nom = '';
      let email = '';

      if (ligne.includes(';')) {
        const parts = ligne.split(';');
        nom = parts[0].trim();
        email = parts[1].trim();
      } else {
        email = ligne.trim();
      }

      if (!email || !email.includes('@')) {
        throw new Error("Adresse email invalide");
      }

      const htmlFinal = htmlTemplate
        .replaceAll('{{nom}}', nom)
        .replaceAll('{{email}}', email);

      GmailApp.sendEmail(
        email,
        sujet,
        "Votre client mail ne supporte pas le HTML.",
        {
          htmlBody: htmlFinal,
          name: "Simplon",
          attachments: attachments
        }
      );

      envoyes.push(email);

    } catch (error) {
      erreurs.push({
        ligne: index + 1,
        contenu: ligne,
        erreur: error.message
      });
    }
  });

  return {
    total: lignes.length,
    envoyes: envoyes.length,
    erreurs: erreurs
  };
}
