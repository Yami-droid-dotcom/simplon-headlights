# Simplon Headlights

Simplon Headlights est un outil interne dédié à l’envoi de mails HTML avec templates, prévisualisation, destinataires rapides et pièces jointes PDF.

Comme les phares d’une voiture, cet outil sert à rendre les informations visibles, claires et bien présentées.

## Fonctionnalités

- Sélection de templates de mails courants
- Prévisualisation HTML avant envoi
- Envoi groupé via GmailApp
- Ajout d’un fichier PDF en pièce jointe
- Bouton rapide pour ajouter le staff Simplon
- Variables personnalisées : `{{nom}}` et `{{email}}`

## Stack technique

- Google Apps Script
- HTML
- CSS
- JavaScript
- GmailApp

## Fichiers principaux

- `Code.gs` : backend Apps Script et envoi Gmail
- `Index.html` : interface utilisateur et templates HTML
- `style.html` : charte graphique de l’interface

## Déploiement

1. Créer un projet Google Apps Script.
2. Ajouter les fichiers `Code.gs`, `Index.html` et `style.html`.
3. Déployer en application web.
4. Autoriser l’accès Gmail au premier envoi.

## Dépôt

Nom conseillé : `simplon-headlights`

Description courte :

> Outil interne d’envoi de mails HTML avec templates, prévisualisation et pièces jointes PDF.
